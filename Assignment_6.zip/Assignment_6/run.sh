javac *.java && java Main

rm *.class